
skinkdiversity <- read.table(file = 'skinkdiversity.txt', header=TRUE);


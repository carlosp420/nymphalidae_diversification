##data skinks
library(ape)
skinktree <- read.tree(file = 'skinktree.tre')




rtrees5 <- scan(file = '5RandomTrees.tre', what = list(""))
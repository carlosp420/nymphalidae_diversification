`read.phy` <-
function(x){
	
	if (length(x) == 1)
		x <- scan(x, what = character(), quiet 	= TRUE)
	semikolon <- grep(";", x)
	if (length(semikolon) > 0){
		x <- gsub(";", "", x)
		warning("\';\' eliminated from input file.")
	}
	ntax <- as.integer(x[1])
	nchar <- as.integer(x[2])
	tax.ind <- seq(3, ntax*2+1, by=2)
	taxnames <- x[tax.ind]
	dna.ind <- tax.ind + 1
	start <- max(dna.ind)
	end <- length(x)
	if (start == end) interleaved <- FALSE 			else interleaved <- TRUE
	obj <- matrix(NA, ntax, nchar)
	for (i in 1:ntax){
		if (interleaved) 									s <- c(x[dna.ind][i], x[seq(start + i, 				end - (ntax - i), by = ntax)])			else s <- x[dna.ind][i] 
		s <- tolower(unlist(strsplit(s, "")))
		obj[i,] <- s
	}
	row.names(obj) <- taxnames
	dna <- "a" %in% obj
	if (dna) obj <- as.DNAbin(obj)
	obj
}

